"""
=============================================================
  ANALISADOR LÉXICO PARA MINI-PASCAL
  Universidade Eduardo Mondlane - LPC 2026
=============================================================
"""

# Palavras reservadas da linguagem conforme o padrão Welsh & McKeag (1980)
PALAVRAS_RESERVADAS = {
    'program', 'var', 'begin', 'end', 'if', 'then', 'else',
    'while', 'do', 'read', 'write', 'array', 'of', 'not',
    'div', 'or', 'and', 'true', 'false', 'char', 'integer',
    'boolean', 'function', 'procedure'
}

class Token:
    """Estrutura para armazenar as propriedades de um token válido."""
    def __init__(self, lexema, classe, linha, coluna):
        self.lexema = lexema
        self.classe = classe
        self.linha = linha
        self.coluna = coluna

class ErroLexico:
    """Estrutura para registar a ocorrência de anomalias léxicas."""
    def __init__(self, lexema, mensagem, linha, coluna):
        self.lexema = lexema
        self.mensagem = mensagem
        self.linha = linha
        self.coluna = coluna

class AnalisadorLexico:
    """Implementação manual do varredor (Scanner) sem geradores automáticos."""
    def __init__(self, codigo_fonte):
        self.codigo = codigo_fonte
        self.pos = 0
        self.linha = 1
        self.coluna = 1

    def _char_atual(self):
        """Retorna o caractere sob o ponteiro atual ou None se atingir o fim."""
        if self.pos >= len(self.codigo):
            return None
        return self.codigo[self.pos]

    def _avancar(self):
        """Avança o ponteiro de leitura e controla o posicionamento de linhas/colunas."""
        ch = self._char_atual()
        self.pos += 1
        if ch == '\n':
            self.linha += 1
            self.coluna = 1
        else:
            self.coluna += 1

    def _espreitar_proximo(self):
        """Olha o próximo caractere sem mover o ponteiro principal (Lookahead)."""
        if self.pos + 1 >= len(self.codigo):
            return None
        return self.codigo[self.pos + 1]

    def _pular_espacos_e_comentarios(self):
        """Descarta espaços em branco e ignora blocos de comentários estruturados { ... }."""
        while self.pos < len(self.codigo):
            ch = self._char_atual()
            if ch is not None and ch.isspace():
                self._avancar()
            elif ch == '{':
                while self.pos < len(self.codigo) and self._char_atual() != '}':
                    self._avancar()
                self._avancar()  # Consome o fecho do comentário '}'
            else:
                break

    def obter_tokens(self):
        """Varre o código-fonte por completo, isolando tokens e recuperando-se de erros."""
        tokens = []
        erros = []

        while self.pos < len(self.codigo):
            self._pular_espacos_e_comentarios()

            if self.pos >= len(self.codigo):
                break

            ch = self._char_atual()
            col_inicio = self.coluna

            # 1. Identificadores e Palavras Reservadas
            if ch.isalpha() or ch == '_':
                lexema = ""
                while self.pos < len(self.codigo) and (self._char_atual().isalnum() or self._char_atual() == '_'):
                    lexema += self._char_atual()
                    self._avancar()
                
                classe = f"RESERVADA_{lexema.upper()}" if lexema.lower() in PALAVRAS_RESERVADAS else "IDENTIFICADOR"
                tokens.append(Token(lexema, classe, self.linha, col_inicio))
                continue

            # 2. Constantes Inteiras
            if ch.isdigit():
                lexema = ""
                while self.pos < len(self.codigo) and self._char_atual().isdigit():
                    lexema += self._char_atual()
                    self._avancar()
                tokens.append(Token(lexema, "CONST_INTEIRA", self.linha, col_inicio))
                continue

            # 3. Constantes de Caracteres (Strings delimitadas por ' ou ")
            if ch in ("'", '"'):
                delimitador = ch
                lexema = ch
                self._avancar()
                
                fechado = False
                while self.pos < len(self.codigo):
                    atual = self._char_atual()
                    lexema += atual
                    self._avancar()
                    if atual == delimitador:
                        fechado = True
                        break
                
                if fechado:
                    tokens.append(Token(lexema, "CONST_CARACTERE", self.linha, col_inicio))
                else:
                    erros.append(ErroLexico(lexema, "Constante de caractere não fechada", self.linha, col_inicio))
                continue

            # 4. Operadores Compostos e Símbolos com Lookahead (:=, .., <>, <=, >=)
            if ch == ':':
                if self._espreitar_proximo() == '=':
                    self._avancar(); self._avancar()
                    tokens.append(Token(':=', 'OP_ATRIBUICAO', self.linha, col_inicio))
                else:
                    self._avancar()
                    tokens.append(Token(':', 'SINAL_DOIS_PONTOS', self.linha, col_inicio))
                continue

            if ch == '.':
                if self._espreitar_proximo() == '.':
                    self._avancar(); self._avancar()
                    tokens.append(Token('..', 'OP_INTERVALO', self.linha, col_inicio))
                else:
                    self._avancar()
                    tokens.append(Token('.', 'SINAL_PONTO_FINAL', self.linha, col_inicio))
                continue

            if ch == '<':
                prox = self._espreitar_proximo()
                if prox == '=':
                    self._avancar(); self._avancar()
                    tokens.append(Token('<=', 'OP_RELACIONAL', self.linha, col_inicio))
                elif prox == '>':
                    self._avancar(); self._avancar()
                    tokens.append(Token('<>', 'OP_RELACIONAL', self.linha, col_inicio))
                else:
                    self._avancar()
                    tokens.append(Token('<', 'OP_RELACIONAL', self.linha, col_inicio))
                continue

            if ch == '>':
                if self._espreitar_proximo() == '=':
                    self._avancar(); self._avancar()
                    tokens.append(Token('>=', 'OP_RELACIONAL', self.linha, col_inicio))
                else:
                    self._avancar()
                    tokens.append(Token('>', 'OP_RELACIONAL', self.linha, col_inicio))
                continue

            # 5. Símbolos Simples Únicos (O caractere '/' foi removido intencionalmente daqui)
            SIMBOLOS_SIMPLES = {
                '+': 'OP_ADICAO', '-': 'OP_SUBTRACAO', '*': 'OP_MULTIPLICACAO',
                '=': 'SINAL_IGUAL', ';': 'SINAL_PONTO_VIRGULA', ',': 'SINAL_VIRGULA',
                '(': 'ABRE_PARENTESIS', ')': 'FECHA_PARENTESIS',
                '[': 'ABRE_CHAVETA', ']': 'FECHA_CHAVETA'
            }

            if ch in SIMBOLOS_SIMPLES:
                self._avancar()
                tokens.append(Token(ch, SIMBOLOS_SIMPLES[ch], self.linha, col_inicio))
                continue

            # 6. Mecanismo de Recuperação de Erros (Modo Pânico)
            # Qualquer caractere fora do alfabeto (incluindo '/') cai aqui
            self._avancar()
            erros.append(ErroLexico(ch, "Caractere inválido", self.linha, col_inicio))

        tokens.append(Token('EOF', 'FIM_DE_FICHEIRO', self.linha, self.coluna))
        return tokens, erros