"""
=============================================================
  MÓDULO DE SUGESTÕES DE CORRECÇÃO COM IA (Claude API)
  Universidade Eduardo Mondlane - LPC 2026
=============================================================
"""

import urllib.request
import json
import threading

# Configure sua chave real aqui
API_KEY = "SUA_API_KEY_AQUI"   # <--- substituir pela chave da equipa

def obter_sugestao_ia(codigo_fonte, erro_lexema, erro_mensagem, linha, coluna, callback):
    def _requisicao_assincrona():
        if API_KEY == "SUA_API_KEY_AQUI":
            callback("(Modo offline) Configure a chave da API no ficheiro sugestoes_ia.py para obter sugestões automáticas.")
            return

        try:
            linhas = codigo_fonte.split('\n')
            inicio = max(0, linha - 3)
            fim = min(len(linhas), linha + 2)
            contexto = "\n".join(linhas[inicio:fim])

            prompt = (
                f"Análise do erro detetado:\n"
                f"  Mensagem: {erro_mensagem}\n"
                f"  Caractere inválido: '{erro_lexema}' na Linha {linha}, Coluna {coluna}.\n\n"
                f"Trecho isolado do código:\n{contexto}\n\n"
                f"Explique resumidamente o erro e dê a correção. Lembre: o caractere '/' é proibido; use 'div' para divisão inteira."
            )

            corpo = json.dumps({
                "model": "claude-sonnet-4-20250514",
                "max_tokens": 150,
                "messages": [{"role": "user", "content": prompt}]
            }).encode('utf-8')

            pedido = urllib.request.Request(
                url="https://api.anthropic.com/v1/messages",
                data=corpo,
                headers={
                    "Content-Type": "application/json",
                    "X-API-Key": API_KEY,
                    "Anthropic-Version": "2023-06-01"
                },
                method="POST"
            )

            with urllib.request.urlopen(pedido, timeout=10) as resp:
                dados = json.loads(resp.read().decode('utf-8'))
                sugestao = dados["content"][0]["text"].strip()
                callback(sugestao)

        except Exception:
            if erro_lexema == '/':
                callback("O operador '/' não é reconhecido. Substitua por 'div' para divisão inteira.")
            else:
                callback(f"Símbolo '{erro_lexema}' inválido. Consulte a tabela de caracteres permitidos.")

    threading.Thread(target=_requisicao_assincrona, daemon=True).start()