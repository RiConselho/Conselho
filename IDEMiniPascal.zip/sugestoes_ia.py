"""
=============================================================
  MÓDULO DE SUGESTÕES DE CORRECÇÃO COM IA (Claude API)
  Universidade Eduardo Mondlane - LPC 2026
=============================================================
"""

import urllib.request
import json
import threading

def obter_sugestao_ia(codigo_fonte, erro_lexema, erro_mensagem, linha, coluna, callback):
    """Executa a requisição HTTP em background para manter a IDE responsiva."""
    
    def _requisicao_assincrona():
        try:
            # Fatiamento inteligente do código fonte circundante para poupar contexto
            linhas = codigo_fonte.split('\n')
            inicio = max(0, linha - 3)
            fim = min(len(linhas), linha + 2)
            contexto = "\n".join(linhas[inicio:fim])

            # Prompt instrutivo parametrizado conforme as restrições léxicas da cadeira
            prompt = (
                f"Análise do erro detetado:\n"
                f"  Mensagem: {erro_mensagem}\n"
                f"  Caractere inválido: '{erro_lexema}' capturado na Linha {linha}, Coluna {coluna}.\n\n"
                f"Trecho isolado do código:\n{contexto}\n\n"
                f"Explique de forma resumida o erro e dê a retificação correta. Importante: Lembre-se que o "
                f"caractere '/' é proibido nesta linguagem. A divisão inteira aceita é unicamente a palavra 'div'."
            )

            # Payload estruturado requisitado pelo modelo da API
            corpo = json.dumps({
                "model": "claude-sonnet-4-20250514",
                "max_tokens": 150,
                "messages": [{"role": "user", "content": prompt}]
            }).encode('utf-8')

            pedido = urllib.request.Request(
                url="https://api.anthropic.com/v1/messages",
                data=corpo,
                headers={
                    "Content-Type": "application/json",
                    "X-API-Key": "SUA_API_KEY_AQUI",  # Inserir o token ativo da equipe
                    "Anthropic-Version": "2023-06-01"
                },
                method="POST"
            )

            with urllib.request.urlopen(pedido, timeout=10) as resp:
                dados = json.loads(resp.read().decode('utf-8'))
                sugestao = dados["content"][0]["text"].strip()
                callback(sugestao)

        except Exception:
            # Mecanismo de contingência offline local estruturado
            if erro_lexema == '/':
                callback("O operador '/' não é reconhecido. Na sintaxe clássica do Mini-Pascal, substitua-o obrigatoriamente pela palavra reservada 'div' para divisões.")
            else:
                callback(f"Símbolo '{erro_lexema}' estranho à linguagem. Verifique a tabela de caracteres aceites pelo alfabeto padrão.")

    # Dispara o worker numa thread paralela isolada
    trabalhador = threading.Thread(target=_requisicao_assincrona)
    trabalhador.daemon = True
    trabalhador.start()