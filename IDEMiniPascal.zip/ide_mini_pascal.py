"""
=============================================================
  IDE MINI-PASCAL — INTERFACE GRÁFICA PRINCIPAL
  Universidade Eduardo Mondlane - LPC 2026
=============================================================
"""

import tkinter as tk
from tkinter import ttk, filedialog, messagebox, font
from analisador_lexico import AnalisadorLexico, Token, ErroLexico
from sugestoes_ia      import obter_sugestao_ia

CORES = {
    'fundo_editor'      : '#1E1E2E', 'fundo_linhas'      : '#181825',
    'fundo_painel'      : '#11111B', 'fundo_barra'       : '#313244',
    'fundo_tabela'      : '#1E1E2E', 'texto_normal'      : '#CDD6F4',
    'texto_reservada'   : '#CBA6F7', 'texto_numero'      : '#FAB387',
    'texto_string'      : '#A6E3A1', 'texto_operador'    : '#89B4FA',
    'erro'              : '#F38BA8', 'sucesso'           : '#A6E3A1'
}

class LinhasLaterais(tk.Canvas):
    """Gera a numeração dinâmica de linhas acompanhando o scroll do editor."""
    def __init__(self, master, text_widget, **kwargs):
        super().__init__(master, **kwargs)
        self.text_widget = text_widget
        
    def atualizar(self):
        self.delete('all')
        i = self.text_widget.index('@0,0')
        while True:
            dline = self.text_widget.dlineinfo(i)
            if not dline:
                break
            num_linha = i.split('.')[0]
            y = dline[0] + (dline[3] / 2)
            self.create_text(25, y, text=num_linha, anchor='center', fill='#585B70', font=self.text_widget['font'])
            i = self.text_widget.index(f"{i}+1line")

class IDEMiniPascal:
    def __init__(self, root):
        self.root = root
        self.root.title("IDE Mini-Pascal (UEM — 2026)")
        self.root.geometry("1150x720")  # CORRIGIDO: Removidas as aspas internas erradas
        self.root.configure(bg=CORES['fundo_painel'])
        self.caminho_ficheiro = None
        
        self.fonte_editor = font.Font(family="Consolas", size=12)
        self._criar_componentes()
        self._carregar_exemplo()

    def _criar_componentes(self):
        # Barra de Menus Superior
        menu_b = tk.Menu(self.root)
        self.root.config(menu=menu_b)
        menu_arq = tk.Menu(menu_b, tearoff=0)
        menu_arq.add_command(label="Novo", command=self._novo_ficheiro)
        menu_arq.add_command(label="Abrir...", command=self._abrir_ficheiro)
        menu_arq.add_command(label="Guardar", command=self._guardar_ficheiro)
        menu_b.add_cascade(label="Ficheiro", menu=menu_arq)
        
        menu_ajuda = tk.Menu(menu_b, tearoff=0)
        menu_ajuda.add_command(label="Especificação Gramática", command=self._mostrar_janela_ajuda)
        menu_b.add_cascade(label="Ajuda", menu=menu_ajuda)

        # Divisão de Painéis Centrais
        painel_split = tk.PanedWindow(self.root, orient=tk.HORIZONTAL, bg=CORES['fundo_painel'], bd=0, sashwidth=4)
        painel_split.pack(fill='both', expand=True, padx=5, pady=5)

        # Editor de Código (Esquerda)
        frame_esq = tk.Frame(painel_split, bg=CORES['fundo_editor'])
        self.canvas_linhas = LinhasLaterais(frame_esq, None, width=45, bg=CORES['fundo_linhas'], bd=0, highlightthickness=0)
        self.canvas_linhas.pack(side='left', fill='y')
        
        self.editor = tk.Text(frame_esq, font=self.fonte_editor, bg=CORES['fundo_editor'], fg=CORES['texto_normal'],
                              insertbackground='white', wrap='none', bd=0, highlightthickness=0)
        self.editor.pack(side='left', fill='both', expand=True)
        self.canvas_linhas.text_widget = self.editor
        
        scroll_y = tk.Scrollbar(frame_esq, command=self._scroll_sincronizado)
        scroll_y.pack(side='right', fill='y')
        self.editor.config(yscrollcommand=scroll_y.set)
        painel_split.add(frame_esq, width=650)

        # Tabela de Saída de Tokens (Direita)
        frame_dir = tk.Frame(painel_split, bg=CORES['fundo_painel'])
        self.tabela = ttk.Treeview(frame_dir, columns=('Lexema', 'Classe', 'Linha', 'Coluna'), show='headings')
        self.tabela.heading('Lexema', text='Lexema'); self.tabela.heading('Classe', text='Classe Léxica')
        self.tabela.heading('Linha', text='Linha'); self.tabela.heading('Coluna', text='Col.')
        self.tabela.column('Lexema', width=120, anchor='center'); self.tabela.column('Classe', width=150, anchor='w')
        self.tabela.column('Linha', width=45, anchor='center'); self.tabela.column('Coluna', width=45, anchor='center')
        self.tabela.pack(fill='both', expand=True, padx=5, pady=5)
        painel_split.add(frame_dir, width=450)

        # Painel de Controle e Mensagens Inferior
        frame_inf = tk.Frame(self.root, bg=CORES['fundo_painel'])
        frame_inf.pack(fill='x', side='bottom', padx=5, pady=5)

        self.btn_analisar = tk.Button(frame_inf, text="▶ EXECUTAR ANÁLISE LÉXICA", bg='#A6E3A1', fg='#11111B',
                                      font=("Segoe UI", 10, "bold"), bd=0, padx=15, pady=6, command=self._executar_analise)
        self.btn_analisar.pack(anchor='w', padx=5, pady=5)

        self.painel_log = tk.Text(frame_inf, height=6, bg=CORES['fundo_painel'], fg=CORES['texto_normal'], font=("Consolas", 10))
        self.painel_log.pack(fill='x', padx=5, pady=5)

        # Triggers de Atualização
        self.editor.bind('<KeyRelease>', lambda e: [self.canvas_linhas.atualizar(), self._colorir_sintaxe()])
        self.editor.bind('<Configure>', lambda e: self.canvas_linhas.atualizar())

    def _scroll_sincronizado(self, *args):
        self.editor.yview(*args)
        self.canvas_linhas.atualizar()

    def _executar_analise(self):
        """Dispara a tokenização e alimenta a tabela e os erros estruturados."""
        for item in self.tabela.get_children():
            self.tabela.delete(item)
        self.painel_log.delete('1.0', tk.END)

        codigo = self.editor.get('1.0', tk.END)
        analisador = AnalisadorLexico(codigo)
        tokens, erros = analisador.obter_tokens()

        for t in tokens:
            self.tabela.insert('', tk.END, values=(t.lexema, t.classe, t.linha, t.coluna))

        if not erros:
            self.painel_log.insert(tk.END, ">>> SUCESSO: Código livre de erros léxicos.\n", 'ok')
            self.painel_log.tag_config('ok', foreground=CORES['sucesso'])
        else:
            self.painel_log.insert(tk.END, f">>> DETETADOS {len(erros)} ERROS LÉXICOS:\n\n", 'erro')
            self.painel_log.tag_config('erro', foreground=CORES['erro'], font=("Consolas", 10, "bold"))
            
            for e in erros:
                detalhe = f"[Erro Lín {e.linha}, Col {e.coluna}]: {e.mensagem} -> Caractere problemático: '{e.lexema}'\n"
                self.painel_log.insert(tk.END, detalhe)
                
                # Invoca o módulo de IA assincronamente para preencher as correções sugeridas
                def callback_ia(resp, l=e.linha):
                    self.painel_log.insert(tk.END, f"💡 Linha {l} (Sugestão IA): {resp}\n\n", 'ia')
                    self.painel_log.tag_config('ia', foreground='#CBA6F7')

                obter_sugestao_ia(codigo, e.lexema, e.mensagem, e.linha, e.coluna, callback_ia)

    def _colorir_sintaxe(self):
        """Mapeador visual dinâmico em tempo real."""
        for tag in self.editor.tag_names():
            self.editor.tag_remove(tag, '1.0', tk.END)

        analisador = AnalisadorLexico(self.editor.get('1.0', tk.END))
        tokens, _ = analisador.obter_tokens()

        for t in tokens:
            if t.classe == 'FIM_DE_FICHEIRO': continue
            ini = f"{t.linha}.{t.coluna - 1}"
            fim = f"{ini}+{len(t.lexema)}c"
            
            if "RESERVADA" in t.classe: self.editor.tag_add('kw', ini, fim)
            elif t.classe == 'CONST_INTEIRA': self.editor.tag_add('num', ini, fim)
            elif t.classe == 'CONST_CARACTERE': self.editor.tag_add('st', ini, fim)
            elif "OP_" in t.classe: self.editor.tag_add('op', ini, fim)

        self.editor.tag_config('kw', foreground=CORES['texto_reservada'], font=(self.fonte_editor.actual()['family'], self.fonte_editor.actual()['size'], 'bold'))
        self.editor.tag_config('num', foreground=CORES['texto_numero'])
        self.editor.tag_config('st', foreground=CORES['texto_string'])
        self.editor.tag_config('op', foreground=CORES['texto_operador'])

    def _novo_ficheiro(self):
        self.editor.delete('1.0', tk.END); self.caminho_ficheiro = None; self.canvas_linhas.atualizar()

    def _abrir_ficheiro(self):
        c = filedialog.askopenfilename(filetypes=[("Mini-Pascal", "*.pas"), ("Texto", "*.txt")])
        if c:
            self.caminho_ficheiro = c
            with open(c, 'r', encoding='utf-8') as f:
                self.editor.delete('1.0', tk.END); self.editor.insert('1.0', f.read())
            self.canvas_linhas.atualizar(); self._colorir_sintaxe()

    def _guardar_ficheiro(self):
        if not self.caminho_ficheiro:
            self.caminho_ficheiro = filedialog.asksaveasfilename(defaultextension=".pas", filetypes=[("Mini-Pascal", "*.pas")])
        if self.caminho_ficheiro:
            with open(self.caminho_ficheiro, 'w', encoding='utf-8') as f:
                f.write(self.editor.get('1.0', tk.END))
            messagebox.showinfo("Sucesso", "Guardado com sucesso!")

    def _carregar_exemplo(self):
        ex = "{ Exemplo Factorial Mini-Pascal }\nprogram Factorial;\nvar\n  n, resultado, i : integer;\nbegin\n  read(n);\n  resultado := 1;\n  i := 1;\n  while i <= n do\n  begin\n    resultado := resultado * i;\n    i := i + 1\n  end;\n  write(resultado)\nend."
        self.editor.insert('1.0', ex)
        self.root.after(80, self._colorir_sintaxe)

    def _mostrar_janela_ajuda(self):
        w = tk.Toplevel(self.root); w.title("Especificação Gramática"); w.geometry("460x380")
        t = tk.Text(w, font=("Consolas", 10), wrap='word')
        t.pack(fill='both', expand=True)
        txt = "Mini-Pascal (Welsh & McKeag, 1980)\n\nPalavras Reservadas:\n  program var begin end if then else while do read write array of not div or and true false char integer boolean function procedure\n\nOperadores Especiais:\n  +  -  * =  <>  <  <=  >  >=  :=\n\nDelimitadores:\n  (  )  [  ]  ,  ;  .  ..  :\n\nComentários suportados:\n  Exclusivamente blocos de chavetas { ... }"
        t.insert('1.0', txt); t.config(state='disabled')

if __name__ == "__main__":
    base = tk.Tk()
    app = IDEMiniPascal(base)
    base.mainloop()